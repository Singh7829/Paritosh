package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ShoppingPage extends TestBase {

    public ShoppingPage(WebDriver driver) {
        this.driver=driver;
    }

    WebDriverWait wait= new WebDriverWait(driver,600);

    private WebElement amazonSearchBox() {
        return driver.findElement(By.cssSelector("input[id='twotabsearchtextbox']"));
    }

    private WebElement flipkartSearchBox(){
        return driver.findElement(By.cssSelector("input[placeholder='Search for products, brands and more']"));
    }

    private WebElement amazonPrice(){
        return driver.findElement(By.xpath("//a//span[contains(text(),\"iPhone XR (64GB) - Yellow\")]/../../../../../../..//span[@class='a-price-whole']"));
    }

    private WebElement flipkartPrice(){
        return driver.findElement(By.xpath("//a//div[contains(text(),\"iPhone XR (Yellow, 64 GB)\")]/../..//div[contains(text(),\"₹\")]"));
    }
   
    public void enterAmazonSearchTerm(String searchTerm) {
        wait.until(ExpectedConditions.elementToBeClickable(amazonSearchBox()));
        amazonSearchBox().click();
        amazonSearchBox().sendKeys(searchTerm);
        amazonSearchBox().sendKeys(Keys.ENTER);
    }

    public int getAmazonPrice(){
        wait.until(ExpectedConditions.elementToBeClickable(amazonPrice()));
        return Integer.parseInt(amazonPrice().getText().replace(",",""));
    }

    public void enterFlipkartSearchTerm(String searchTerm) {
        flipkartSearchBox().click();
        flipkartSearchBox().sendKeys(searchTerm);
        flipkartSearchBox().sendKeys(Keys.ENTER);
    }

    public int getFlipkartPrice(){
        wait.until(ExpectedConditions.visibilityOfAllElements(flipkartPrice()));
        return Integer.parseInt(flipkartPrice().getText().replace(",","").replace("₹",""));
    }
}
