package tests;

import pages.ShoppingPage;
import pages.TestBase;
import org.testng.annotations.Test;

public class PriceCompareTest extends TestBase  {

    String searchTerm="iPhone XR (64GB) - Yellow";
    String amazonUrl= "https://www.amazon.in";
    String flipkartUrl="https://www.flipkart.com/search";
    int flipkartPrice;
    int amazonPrice;
    int lowestPrice;
    String lowestPriceSiteName;

    @Test
    public void comparePriceTest()
    {
        navigateToUrl(amazonUrl);
        ShoppingPage shoppingPage = new ShoppingPage(driver);
        shoppingPage.enterAmazonSearchTerm(searchTerm);
        amazonPrice= shoppingPage.getAmazonPrice();

        navigateToUrl(flipkartUrl);
        shoppingPage.enterFlipkartSearchTerm(searchTerm);
        flipkartPrice= shoppingPage.getFlipkartPrice();

        lowestPrice = (flipkartPrice<amazonPrice) ? flipkartPrice: amazonPrice;
        lowestPriceSiteName= (flipkartPrice<amazonPrice) ? "Flipkart": "Amazon";

        System.out.println("The Product Price on Amazon is: "+amazonPrice);
        System.out.println("The Product Price on flipkart is: "+flipkartPrice);
        System.out.println("The lowest Price is : "+lowestPrice+ " on "+lowestPriceSiteName);
    }
}
