package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class TestBase {

    public static WebDriver driver;

    @BeforeSuite
    public void createDriver()
    {
    	System.setProperty("webdriver.chrome.driver" ,"C:\\Users\\parit\\Downloads\\chromedriver\\chromedriver.exe");
        this.driver =new ChromeDriver();
        driver.manage().window().maximize();
    }

    public void navigateToUrl(String url) {
        driver.get(url);
    }

    @AfterSuite
    public void tearDown(){
        driver.close();
        driver.quit();
    }
}
