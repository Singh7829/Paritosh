package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class ReviewPage extends TestBase {

    public ReviewPage(WebDriver driver) {
        this.driver=driver;
    }

    WebDriverWait wait= new WebDriverWait(driver,120);

    private WebElement searchBox() {
        return driver.findElement(By.xpath("//span[contains(text(),'Search')]"));
    }

    private WebElement mainSearchBox(){
        return driver.findElement(By.cssSelector("input[id='mainSearch']"));
    }

    private WebElement writeReviewLink(){
        return driver.findElement(By.xpath("//a[contains(text(),'Write a review')]"));
    }

    private By WriteReviewLink_By= By.xpath("//a[contains(text(),'Write a review')]");

    private WebElement ratingText(){
        return driver.findElement(By.xpath("//div[@id='ratingFlag']//em"));
    }

    private WebElement hotelRatingText(){
        return driver.findElement(By.xpath("//div[contains(text(),'Hotel Ratings')]/..//span[contains(@id,\"bubbles\")]/../../div[@class='ratingText short']"));
    }

    private WebElement reviewTitle(){
        return driver.findElement(By.xpath("//input[@id='ReviewTitle']"));
    }

    private WebElement reviewText() {
        return driver.findElement(By.xpath("//textarea[@id='ReviewText']"));
    }

    public List<WebElement> hotelRatings(){
        return driver.findElements(By.xpath("//div[contains(text(),'Hotel Ratings')]"));
    }

    private WebElement starRatingIcon(){
        return driver.findElement(By.cssSelector("span[id='bubble_rating']"));
    }

    private WebElement hotelStarRatingIcon() {
        return driver.findElement(By.xpath("//div[contains(text(),'Hotel Ratings')]/..//span[contains(@id,\"bubbles\")]"));
    }

    private WebElement submitReviewCheckBox(){
        return driver.findElement(By.cssSelector("input[id='noFraud']"));
    }

    private WebElement firstListing(){
        return driver.findElement(By.cssSelector("div[class='result-title'] span"));
    }

    public void enterSearchTerm(String searchTerm) {
        wait.until(ExpectedConditions.elementToBeClickable(searchBox()));
        searchBox().click();
        wait.until(ExpectedConditions.elementToBeClickable(mainSearchBox()));
        mainSearchBox().click();
        mainSearchBox().sendKeys(searchTerm);
        mainSearchBox().sendKeys(Keys.ENTER);
    }

    public void clickFirstListing(){
        wait.until(ExpectedConditions.elementToBeClickable(firstListing()));
        firstListing().click();
    }

    public void clickReviewLink(){
        wait.until(ExpectedConditions.presenceOfElementLocated(WriteReviewLink_By));
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].click();", writeReviewLink());
    }

    public void click5StarReviewLink(){
        Actions actions= new Actions(driver);
        actions.dragAndDropBy(starRatingIcon(),50,0).build().perform();
    }

    public String getRatingText(){
        wait.until(ExpectedConditions.visibilityOf(ratingText()));
        return ratingText().getText();
    }

    public void enterReviewTitle(String reviewTitle){
        wait.until(ExpectedConditions.visibilityOf(reviewTitle()));
        reviewTitle().click();
        reviewTitle().sendKeys(reviewTitle);
    }

    public void enterReviewText(String reviewText){
        wait.until(ExpectedConditions.visibilityOf(reviewText()));
        reviewText().click();
        reviewText().sendKeys(reviewText);
    }

    public String clickHotelStarandGetRating() {
        Actions actions= new Actions(driver);
        actions.moveToElement(hotelStarRatingIcon()).build().perform();
        actions.dragAndDropBy(hotelStarRatingIcon(),50,0).build().perform();
        return hotelRatingText().getText();
    }

    public void clickSubmitReviewCheckBox(){
        Actions actions= new Actions(driver);
        actions.moveToElement(submitReviewCheckBox()).build().perform();
        submitReviewCheckBox().click();
    }
}
