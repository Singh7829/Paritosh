package tests;

import pages.ReviewPage;
import pages.TestBase;
import org.testng.annotations.Test;
import java.util.ArrayList;

public class ReviewTest extends TestBase  {

    String tripadvisorUrl= "https://www.tripadvisor.in";
    String searchTerm="Club Mahindra";


    @Test
    public void reviewTest()
    {
        navigateToUrl(tripadvisorUrl);
        ReviewPage reviewPage = new ReviewPage(driver);
        reviewPage.enterSearchTerm(searchTerm);
        reviewPage.clickFirstListing();
        driver.switchTo().window(new ArrayList<String>(driver.getWindowHandles()).get(1));
        reviewPage.clickReviewLink();
        driver.switchTo().window(new ArrayList<String>(driver.getWindowHandles()).get(2));
        reviewPage.click5StarReviewLink();
        String ratingText= reviewPage.getRatingText();
        System.out.println("Clicked on 5 Star Review Ratings and Review Rating Text is : "+ratingText);
        reviewPage.enterReviewTitle("Sample Review Title");
        reviewPage.enterReviewText("Sample Review Text");
        if(reviewPage.hotelRatings().size()>0) {
            String hotelText = reviewPage.clickHotelStarandGetRating();
            System.out.println("Clicked on 5 Star under Hotel Ratings and Rating Text is : "+hotelText);
        }
        else
            System.out.println("Hotel Ratings is not available");
        reviewPage.clickSubmitReviewCheckBox();
    }
}
